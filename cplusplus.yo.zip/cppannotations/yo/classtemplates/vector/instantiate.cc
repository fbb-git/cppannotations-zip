    #include "vector.h"

    void add(Vector<int> &vector, int value)
    {
        vector.push_back(value);
    }
