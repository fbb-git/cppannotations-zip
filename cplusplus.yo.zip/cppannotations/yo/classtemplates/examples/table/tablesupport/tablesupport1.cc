#include "tablesupport.ih"

TableSupport::TableSupport()
//:
{
}
