    #include "sumvector.h"

    template      int sumVector<int>(int *, size_t);
    template   double sumVector<double>(double *, size_t);
    template size_t sumVector<size_t>(size_t *, size_t);
