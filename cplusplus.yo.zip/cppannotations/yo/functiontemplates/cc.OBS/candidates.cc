    #include "candidates.h"

    int main()
    {
        differentSigns(int(), double());
    }
