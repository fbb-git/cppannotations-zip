    #include <iostream>
    #include "specialization.h"

    int main(int argc, char **argv)
    {
        std::cout << sumVector(argv, argc);
    }
