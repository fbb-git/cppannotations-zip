template <typename T1, typename T2>
concept bool Concept = true;


// // OK: auto is invented to be an int
// template <typename T1, int N>
// struct Array{};
//
//
// template <int N> void function(Array<auto, N>);
//
// int main()
// {
//     Array<int, 4> arr;
//
//     function(arr);
// }

// // OK: Same: in this case typename is explicitly mentioned in the
// //      template header, instead of implicitly using auto
// template <typename T1, int N>
// struct Array{};
//
//
// template <int N, typename T> void function(Array<T, N>);
//
// int main()
// {
//     Array<int, 4> arr;
//
//     function(arr);
// }
