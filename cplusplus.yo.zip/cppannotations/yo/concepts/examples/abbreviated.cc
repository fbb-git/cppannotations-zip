#include <vector>

using namespace std;

void function(vector<auto *> ...);

template <typename ...Params>
struct Tuple {};

void function3(Tuple<auto ...>);        // WC, should compile according to
                                        // N4377, p 19.
template <typename ...Tp>
void function2(Tuple<Tp...>);


int main()
{
    vector<int *> vip;

    function(vip, vip);
}
