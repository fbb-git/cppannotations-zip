#include <vector>
#include <iostream>

struct Object
{
    Object() = default;
//    Object(Object const &other) = delete;
};

//COPYABLE
template <typename  Type>
requires std::is_copy_constructible<Type>::value and
         not std::is_floating_point<Type>::value
using cvector = std::vector<Type>;

int main()
{
    cvector<Object> co;
    cvector<double> cd;

}
//=
