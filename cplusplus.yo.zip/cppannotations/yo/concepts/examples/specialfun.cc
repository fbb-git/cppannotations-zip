#include <iostream>

using namespace std;

template <typename Type1, typename Type2>
void fun(Type1 tp1, Type2 tp2)
{
    cout << "generic\n";
};

template <typename Type>           // partial specialization for function
void fun(Type *tp1, Type tp)
{
    cout << "pointer specialized\n";
};


template <typename Type>           // partial specialization for function
void fun(int tp1, Type tp)
{
    cout << "specialized\n";
};


int main()
{
    fun(3, 4.5);
    fun(3.5, 4);
}
