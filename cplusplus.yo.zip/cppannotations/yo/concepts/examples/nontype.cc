#include <iostream>
using namespace std;

//constexpr bool isPrime(int test, int sqr, int value)
//{
//    return
//        value % test == 0 ? false :
//        sqr > value ? true :
//        isPrime(test + 1, sqr + 2 * test + 1, value);
//}

//ISPRIME
constexpr bool isPrime(int value, int test = 2)
{
    return
        value % test == 0 ?   false :
        test * test > value ? true :
                              isPrime(value, test + 1);
}
//=

//PRIME
template <int Value>
concept bool Prime()
{
    return Value > 1000 && isPrime(Value);
}
//=

template <int Nr>
void fun()
{
    cout << "unconstrained\n";
}

template <Prime Nr>
void fun()
{
    cout << "prime\n";
};

template <typename Key, typename Value, int Size>
    requires Prime<Size>()
struct HashTable2
{
    void fun();
};


template <typename Key, typename Value, Prime Size>
struct HashTable
{
    void fun();
};

int main()
{
    HashTable<int, int, 1009> htOK;
    htOK.fun();

    HashTable2<int, int, 1009> htOK2;
    htOK2.fun();

//    HashTable<int, int, 1012> htNotOK;
//    htNotOK.fun();

    fun<1009>();
    fun<1012>();

}
