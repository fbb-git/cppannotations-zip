#include <vector>

struct Object
{
    Object() = default;

    Object(Object const &other) = delete;
};

using namespace std;
//    using namespace std::literals::string_literals;

template <typename Type>
concept bool Copyable()
{
    return std::is_copy_constructible<Type>::value;
};

template <Copyable Type>
struct Wrap: public vector<Type>
{};

template <Copyable Type>
using cvector = vector<Type>;

int main()
{
//    Wrap<Object> vw;
//    vw.push_back(Object{});
//
//    vector<Object> vm;
    cvector<Object> co;

//    vm.push_back(Object{});
}
