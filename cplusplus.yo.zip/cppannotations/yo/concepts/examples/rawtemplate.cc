#include <vector>
struct Object
{
    Object() = default;
    Object(Object const &other) = delete;
};

int main()
{
    std::vector<Object> vo;
    vo.push_back(Object{});
}
