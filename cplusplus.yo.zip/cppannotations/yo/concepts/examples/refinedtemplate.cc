#include <vector>
struct Object
{
    Object() = default;
    Object(Object const &other) = delete;
};

//DEFINITION
template <typename Type>
concept bool Copyable()
{
    return std::is_copy_constructible<Type>::value;
};
//=
//COPYABLE
template <Copyable Type>
using cvector = std::vector<Type>;

int main()
{
    cvector<Object> co;
}
//=
