//CP
template <typename Param>
concept bool Concept()
{
    return true;
}

template <typename Param>
    requires Concept<Param>()
void fun(Param param);
//=

template <Concept Param>
void fun2(Param param);

//MULTI
template <typename First, typename Second>
concept bool Concept()
{
    return true;
}

template <typename Ret, typename Param>
    requires Concept<Ret, Param>()
Ret fun(Param param);
//=

Concept{Ret, Param}
Ret fun2(Param param);

template <typename First, typename Second = int>
concept bool Concept2()
{
    return true;
}

Concept2{Ret, First} struct Array {};

// Array<int> a1; WC: defaults are not available
Array<int, double> a2;

template <typename One>
    requires Concept2<One>()
struct Ar1 {};

Ar1<int> ar1_a;
