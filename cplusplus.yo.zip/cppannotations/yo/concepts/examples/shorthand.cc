//CP
template <typename Param>
concept bool Concept()
{
    return true;
}

template <typename Param>
    requires Concept<Param>()
void fun(Param param);
//=

template <Concept Param>
void fun2(Param param);

//MULTI
template <typename First, typename Second>
concept bool Concept()
{
    return true;
}

template <typename Ret, typename Param>
    requires Concept<Ret, Param>()
Ret fun(Param param);
//=

Concept{Ret, Param}
Ret fun2(Param param);
