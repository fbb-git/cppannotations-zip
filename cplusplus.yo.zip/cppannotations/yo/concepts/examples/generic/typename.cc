template <typename T>
void fun()
{
    typename Value_type<T>;

    Value_type<T> tp;
}
