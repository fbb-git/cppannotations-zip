#include <algorithm>
#include <vector>
#include <string>

using namespace std;

template <typename Type>
concept bool Comparable()
{
    return requires(Type lhs, Type rhs)
    {
        { lhs < rhs } -> bool;
    };
}

struct Data
{};

//bool operator<(Data const &lhs, Data const &rhs)
//{
//    return true;
//}

int main()
{
    vector<string> vs;

//    sort(vs.begin(), vs.end(),
//        [&](auto lhs, auto rhs)
//        {
//            return lhs < rhs;
//        }
//    );

    vector<Data> vd;

    auto lambda =
        [](Comparable const &lhs, Comparable const &rhs)
        {
            return lhs < rhs;
        }
    ;
//
//    lambda(vd[0], vd[1]);

//    sort(vd.begin(), vd.end(),
//        // lambda);
//        [&](Comparable lhs, Comparable rhs)
//        {
//            return lhs < rhs;
//        }
//    );

//    bool sort(decltype(vd.begin()), decltype(vd.end()), decltype(lambda) lb);

    sort<   decltype(vd.begin()),
            decltype(lambda)
        >(vd.begin(), vd.end(), lambda);

}
