#include <string>

//CODE
struct Demo
{
    Demo() = default;
    Demo(Demo const &&&other) = delete;
};

template <typename Type>
struct Object
{
    Object(Type &&value)
    requires std::is_copy_constructible<Type>::value;

    template <typename Tp>
    void fun(Tp const &tp) const
    requires std::is_copy_constructible<Tp>::value;
};

template <typename Type>
template <typename Tp>
void Object<Type>::fun(Tp const &tp) const
requires std::is_copy_constructible<Tp>::value
{}
//=

int main()
{
    Object<std::string> obj{std::string{}};
//    Object<Demo> obj2{Demo{}};

    obj.fun(std::string{});
}
