struct NonType
{
    int val;
};

template <typename Tp>
concept bool NonType = true;

template <NonType>
void fun(NonType tp)
{
    tp.val = 5;
}
