#include <initializer_list>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>

using namespace std;

struct Multipliable
{};

Multipliable operator*(Multipliable lhs, Multipliable rhs)
{
    return lhs;
}

struct Multipliable2
{};

Multipliable2 operator*(Multipliable2 lhs, Multipliable2 rhs)
{
    return lhs;
}

// template <typename T>
// T compute(initializer_list<T> list)
// {
//     T ret = accumulate(list.begin(), list.end(), T{}, operator*);
//     return ret;
// }

// Same Assignable types or Assignable required for the individual params:

    template <typename Type>
    concept bool Assignable = true;

    void fun(Assignable one, Assignable two)        // same argument types
    {};                                             // required.

    //template <typename T1, typename T2>           // assignable, but
    //    requires Assignable<T1> && Assignable<T2> // potentially differently
    //void fun(T1 one, T2 two)                      // typed arguments
    //{};


int main(int argc, char **argv)
{
//        fun(int{}, string{});
//        fun(int{}, int{});

    vector<string> vs;

    char const *target = "hello";

    auto lambda =
        [target](auto const &str)
        {
            return str == target;
        };

    find_if(vs.begin(), vs.end(), lambda);

    vector<int> vi;
//    find_if(vi.begin(), vi.end(), lambda);


    auto multi =
        [](auto lhs, auto rhs)
        {
            return lhs * rhs;
        };

    vector<Multipliable> vm;
//    accumulate(vm.begin(), vm.end(), Multipliable{}, operator*); // WC
    accumulate(vm.begin(), vm.end(), Multipliable{}, multi);  // OK
//    Multipliable x =
//            accumulate(vm.begin(), vm.end(), Multipliable{}, operator*); //!OK
//    compute({Multipliable{}, Multipliable{} }); WC

    vector<Multipliable2> vm2;
    accumulate(vm2.begin(), vm2.end(), Multipliable2{}, multi); // OK
}
