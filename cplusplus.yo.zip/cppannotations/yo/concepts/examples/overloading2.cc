// In this example the concept BidirectionalIterator, defined as a variable
// template is extended by RandomIterator, defining a more constrained
// concept.

#include <iostream>
#include <vector>
#include <list>

struct Incrementable
{
    Incrementable &operator++()
    {
        return *this;       // just for the demo
    }
};

template <typename Iterator>
void step(Iterator &iterator, size_t nSteps)
{
    std::cout << "generic step\n";
    for ( ; nSteps--; )
        ++iterator;
}

template <typename Iter>
concept bool BiDirectionalIterator =
    requires(Iter iter)
    {
        ++iter;
        --iter;
    };

template <BiDirectionalIterator Iterator>
void step(Iterator &iterator, int nSteps)
{
    std::cout << "bidirectional step\n";
    if (nSteps > 0)
    {
        for ( ; nSteps--; )
            ++iterator;
    }
    else if (nSteps < 0)
    {
        for ( ; nSteps; ++nSteps)
            ++iterator;
    }
}

template <BiDirectionalIterator Iter>
concept bool RandomIterator()
{
    return
    requires(Iter iter, int stepSize)
    {
        requires (BiDirectionalIterator<Iter>);
        iter += stepSize;
    };
}

template <RandomIterator Iterator>
void step(Iterator &iterator, int nSteps)
{
    std::cout << "random step\n";
    iterator += nSteps;
}

using namespace std;

int main()
{
    Incrementable incrementable;
    step(incrementable, 4);

    list<int> li;
    auto begin = li.begin();
    step(begin, 4);
    step(begin, -4);

    vector<int> vi;
    auto vbeg = vi.begin();
    step(vbeg, 4);
    step(vbeg, -4);

}
