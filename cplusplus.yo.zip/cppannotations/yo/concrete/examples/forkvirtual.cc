    #include "fork.ih"

//REDIRECT
    void Fork::childRedirections()
    {}
    void Fork::parentRedirections()
    {}
//=

    Fork::~Fork()
    {}
