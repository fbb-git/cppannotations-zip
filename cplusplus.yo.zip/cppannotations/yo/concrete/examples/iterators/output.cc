#include "input.h"
#include "output.h"

#include <algorithm>

int main()
{
    copy(InputIterator(0), InputIterator(100), OutputIterator(0));
}
