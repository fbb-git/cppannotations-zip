#include "input.h"

#include <algorithm>

int main()
{
    accumulate(InputIterator(0), InputIterator(100), 0);
}
