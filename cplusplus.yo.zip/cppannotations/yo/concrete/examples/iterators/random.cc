#include "random.h"

#include <algorithm>

int main()
{
    sort(RandomIterator(0), RandomIterator(100));
}
