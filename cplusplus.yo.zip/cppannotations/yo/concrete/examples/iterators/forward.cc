#include "forward.h"

#include <algorithm>

int main()
{
    adjacent_find(ForwardIterator(0), ForwardIterator(100));
}
