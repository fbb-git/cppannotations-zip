#include "parser.ih"

void Parser::done() const
{
    cout << "Good bye\n";
    ACCEPT();
}
