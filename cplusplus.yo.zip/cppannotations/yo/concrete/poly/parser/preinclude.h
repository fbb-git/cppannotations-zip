#ifndef INCLUDED_PREINCLUDE_H_
#define INCLUDED_PREINCLUDE_H_

#include "../int/int.h"
#include "../text/text.h"

#include "../semantic/semantic.h"

#endif
