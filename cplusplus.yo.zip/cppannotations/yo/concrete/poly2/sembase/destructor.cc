#include "sembase.h"

SemBase::~SemBase()
{}
