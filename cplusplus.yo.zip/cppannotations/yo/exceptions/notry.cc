
int main()
{
    throw "hello";
}
