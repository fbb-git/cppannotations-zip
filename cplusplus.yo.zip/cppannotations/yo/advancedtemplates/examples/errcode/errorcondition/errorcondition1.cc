#include "errorcondition.ih"

ErrorCondition::ErrorCondition()
:
    d_ec(ConditionCategory::instance())
{}
