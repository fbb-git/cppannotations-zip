#include "errorcondition.ih"

ErrorCondition *ErrorCondition::s_instance;
