#include "simulatorcategory.ih"

char const *SimulatorCategory::name() const noexcept
{
    return "simulator";
}
