#include "conditioncategory.ih"

ConditionCategory *ConditionCategory::s_instance;
