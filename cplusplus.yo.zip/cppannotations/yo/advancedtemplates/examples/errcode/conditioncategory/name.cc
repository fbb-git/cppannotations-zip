#include "conditioncategory.ih"

char const *ConditionCategory::name() const noexcept
{
    return "error-condition";
}
