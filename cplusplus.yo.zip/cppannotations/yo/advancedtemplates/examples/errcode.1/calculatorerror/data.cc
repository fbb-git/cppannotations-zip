#include "calculatorerror.ih"

#include "calculatorerror.ih"

                                    // define the singleton
CalculatorCategory const calculatorCategory;
