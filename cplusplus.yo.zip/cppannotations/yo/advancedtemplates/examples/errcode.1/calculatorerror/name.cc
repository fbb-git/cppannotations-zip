#include "calculatorerror.ih"

char const *CalculatorCategory::name() const noexcept
{
    return "calculator";
}
