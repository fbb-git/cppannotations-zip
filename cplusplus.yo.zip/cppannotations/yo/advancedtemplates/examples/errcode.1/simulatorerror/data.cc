#include "simulatorerror.ih"

SimulatorCategory const simulatorCategory;
