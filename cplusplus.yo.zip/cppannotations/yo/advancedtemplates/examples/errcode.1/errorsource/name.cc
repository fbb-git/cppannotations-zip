#include "errorsource.ih"

char const *ErrorCategory::name() const noexcept
{
    return "error-source";
}
