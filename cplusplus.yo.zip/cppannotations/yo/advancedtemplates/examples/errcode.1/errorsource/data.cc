#include "errorsource.ih"

                                    // define the singleton
ErrorCategory const errorCategory;
