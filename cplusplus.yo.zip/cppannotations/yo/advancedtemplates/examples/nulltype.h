#ifndef INCLUDED_NULLTYPE_H_
#define INCLUDED_NULLTYPE_H_

struct NullType
{};

#endif
